export const state = {
  deletedCodestablecimientos: new Set<number>(),
};
