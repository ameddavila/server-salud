declare global {
  var deletedCodestablecimientos: Set<number> | undefined;
}

export {};
